public class Program_11 {
	public static void main(String args[]) {
		int b;
		for (b = 23; b < 57; b++) {
			if (b % 2 == 0)
				System.out.println(b);
		}
	}
}
