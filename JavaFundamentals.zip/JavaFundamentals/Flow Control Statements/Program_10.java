public class Program_10 {
	public static void main(String args[]) {
		int a;
		for (a = 1; a < 10; a++)
			System.out.print(a + " ");
		System.out.print(a);
	}
}
